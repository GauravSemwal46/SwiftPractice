import UIKit

//Property Observers

struct Bank {
    var accountBalance: Double {
        //Did set is called when value is set to property.
        didSet {
            sendMessageToUser()
        }
        //Will Set will called first
        willSet (newAccountBalance){
            print("new account balance is \(newAccountBalance)")
        }
    }
    
    init(_openingBalance: Double) {
        accountBalance = _openingBalance
    }
    
    //Inside a struct if you want to change any property you need to make the function mutating by default function are immutable
    mutating func addMoney(amount: Double) {
        accountBalance += amount
    }
    
    mutating func withDrawMoney(amount: Double) {
        accountBalance -= amount
    }
    
    func sendMessageToUser() {
        print("Account balance updated new balance = \(accountBalance)")
    }
}
//You cannot call a mutating function with a let object. you need to make the object var.
var bank = Bank(_openingBalance: 10000)

bank.addMoney(amount: 5000)


/*class Bank {
    //Property observer
    var accountBalance: Double {
        didSet {
            sendMessageToUser()
        }
        willSet (newAccountBalance){
            if (newAccountBalance >= 100000) {
                sendMessageToAuditor()
            }
        }
    }
    
    init(_openingBalance: Double) {
        accountBalance = _openingBalance
    }
    
    func addMoney(amount: Double) {
        accountBalance += amount
    }
    
    func withDrawMoney(amount: Double) {
        accountBalance -= amount
    }
    
    func sendMessageToUser() {
        print("Account balance updated new balance = \(accountBalance)")
    }
    
    func sendMessageToAuditor() {
        print("Please check this account, and verify if trasaction is authentic")
    }
}

let bank = Bank(_openingBalance: 10000)
bank.addMoney(amount: 5000)
bank.withDrawMoney(amount: 3000)
bank.addMoney(amount: 5000000)*/

