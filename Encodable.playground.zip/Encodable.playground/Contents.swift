import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

struct EndPoint {
    static let registerUrl = "http://api-dev-scus-demo.azurewebsites.net/api/User/RegisterUser"
    static let getUser = "http://api-dev-scus-demo.azurewebsites.net/api/User/GetUser"
}

struct UserRegisterRequest: Encodable {
    let Name, Email, Password: String
    
    enum CodingKeys: String, CodingKey {
        case Name = "name"
        case Email = "email"
        case Password = "password"
    }
}

struct UserRegisterationResponse: Decodable {
    let errorMessage: String
    let data: UserData
}

// MARK: - DataClass
struct UserData: Codable {
    let name, email, id, joining: String
}


struct User {
    
    func registerUserWithEncodableProtocol() {
        var urlRequest = URLRequest(url: URL(string: EndPoint.registerUrl)!)
        urlRequest.httpMethod = "post"
        
        let request = UserRegisterRequest(Name: "John", Email: "johndoe@gmail.com", Password: "1234")
        do {
            let requestBody = try JSONEncoder().encode(request)
            urlRequest.httpBody = requestBody
            urlRequest.addValue("application/json", forHTTPHeaderField: "content-type")
        } catch let error {
            print(error.localizedDescription)
        }
        
        URLSession.shared.dataTask(with: urlRequest) { (data, httpUrlResponse, error) in
            if(data != nil && data?.count != 0) {
//                let response = String(data: data!, encoding: .utf8)
//                print(response)
                do {
                    let response = try JSONDecoder().decode(UserRegisterationResponse.self, from: data!)
                    print(response.data.name)
                } catch let decodingError {
                    print(decodingError)
                }
            }
        }.resume()
    }
    
    func registerUser() {
        //Code to register user
        var urlRequest = URLRequest(url: URL(string: EndPoint.registerUrl)!)
        urlRequest.httpMethod = "post"
        
        let dataDictionary = ["name": "Gaurav", "email": "gauravsemwal610@gmail.com", "password":"1234"]
        do {
            let requestBody = try JSONSerialization.data(withJSONObject: dataDictionary, options: .prettyPrinted)
            urlRequest.httpBody = requestBody
            urlRequest.addValue("application/json", forHTTPHeaderField: "content-type")
        } catch let error {
            print(error.localizedDescription)
        }
        
        URLSession.shared.dataTask(with: urlRequest) { (data, httpUrlResponse, error) in
            if(data != nil && data?.count != 0) {
                let response = String(data: data!, encoding: .utf8)
                print(response)
            }
        }.resume()
        
    }
    
    func getUserFromServer() {
        var urlRequest = URLRequest(url: URL(string: EndPoint.getUser)!)
        urlRequest.httpMethod = "get"
        
        URLSession.shared.dataTask(with: urlRequest) { (data, httpUrlResponse, error) in
            if(data != nil && data?.count != 0) {
                let response = String(data: data!, encoding: .utf8)
                print(response)
            }
        }.resume()
    }
}

let objUser = User()
objUser.registerUserWithEncodableProtocol()
