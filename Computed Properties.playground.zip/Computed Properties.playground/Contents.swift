import UIKit

// Computed properties

struct LoanCalculator {
    var loanAmount: Int
    var rateOfInterest: Int
    var year: Int
    //Computed Properties - You cannot make it let as property is calculated at run time.
    //You cannot assign any value to computed property
    var simpleInterest: Int {
        get {
            return (loanAmount * rateOfInterest * year) / 100
        }
    }
}

let loanCalculator = LoanCalculator(loanAmount: 50000, rateOfInterest: 10, year: 5)
debugPrint("Interest amount = \(loanCalculator.simpleInterest)")


struct Circle {
    var radius: Double = 0
    var area: Double {
        get {
            return radius * radius * Double.pi
        }
        set(areaValue) {
            radius = sqrt(areaValue / Double.pi)
        }
    }
}

var circle = Circle()
circle.radius = 5
print("Area = \(circle.area)")

circle.area = 40
print("Radius = \(circle.radius)")
