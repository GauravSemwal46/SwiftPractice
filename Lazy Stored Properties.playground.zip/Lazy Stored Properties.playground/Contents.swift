import UIKit

// Lazy stored properties

// A lazy stored property is a property whose initial value is not calculated until the first time it is used. You indicate a lazy stored property by writing the lazy modifier before its declaration

struct MusicRequest: Encodable {
    let id: Int
}

struct MusicDownloader {
    func download(request: MusicRequest, completionHandler: @escaping(_ result: Data?)->()) {
        //Your code to download media from an API
        URLSession.shared.dataTask(with: URLRequest(url: URL(string: "Your API URL")!)) {
            (musicData, response, error) in
            if(error == nil) {
                completionHandler(musicData)
            }
            completionHandler(nil)
        }
    }
}

struct Playlist {
    lazy var helper: MusicDownloader = MusicDownloader()
    let songName: String = "Song Name"
    let volume: Double = 5
    
    mutating func downloadForOffline() {
        helper.download(request: MusicRequest(id:1)) { (mediaData) in
            //stored the media data you received
        }
    }
    
    func getUsersPlaylist() {
        //download playlist from API
    }
}

var obj = Playlist()
print(obj.helper)

struct ComplexTask {
    static var firstElement: Int = 1
    static var result: Int = 0
    
    static func doComplexTask() -> Int {
        var task: [Int] = []
        for i in firstElement...5000 {
            task.append(i)
        }
        result = task.first!
        return result
    }
}

struct Employee {
    lazy var complexTask: Int = {ComplexTask.doComplexTask()}()
    var computedTask: Int {
        ComplexTask.doComplexTask()
    }
}

var objEmployee = Employee()
print(objEmployee.complexTask)
print(objEmployee.computedTask)

ComplexTask.firstElement = 100
print(objEmployee.complexTask)
print(objEmployee.computedTask)
// You can set value of lazy type only one time and not multiple time
//Lazy property are not thread safe
