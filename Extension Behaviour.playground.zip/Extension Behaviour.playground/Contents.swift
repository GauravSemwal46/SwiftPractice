import UIKit

// Extension Behaviour

// Swift give a compile time error if we are storing a stored property in the extension

/*Example -
extension Vehicle {
 var modelNumber: Int = 15
 }*/

// By default the properties we are using in the class or struct are known as stored properties
// Two type of properties are stored and computed properties

protocol Vehicle {
    var engineCapacity: String {get set}
    var capacity: Int {get set}
    func startEngine()
}

extension Vehicle {
    var make: String {
        get {
            return "Audi"
        }
    }
}

class Bike: Vehicle {
    var engineCapacity: String = String()
    var capacity: Int
    
    init(_capacity: Int) {
        capacity = _capacity
    }
    
    func startEngine() {
        // code to start engine
    }
}

