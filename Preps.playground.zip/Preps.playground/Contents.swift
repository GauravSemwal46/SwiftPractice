import UIKit

func getPigLatin(array: [Character]) -> [Character] {
    var result = array
    var vowelIndex = -1
    for (index, value) in result.enumerated() {
        print(index,value)
        let lowerCasedValue = value.lowercased()
        
        if ["a","e","i","o","u"].contains(lowerCasedValue) {
            vowelIndex = index
            break
        }
    }
    print(vowelIndex)
    if vowelIndex <= 0 {
        print("Answer is = \(array)")
        return array
    }
    result = reverse(array: result, startIndex: 0, endIndex: vowelIndex-1)
    result = reverse(array: result, startIndex: vowelIndex, endIndex: result.count-1)
    result = reverse(array: result, startIndex: 0, endIndex: result.count-1)
    print("Answer is =\(result)")
    return result
}

func reverse(array: [Character], startIndex: Int, endIndex: Int) -> [Character] {
    var result = array
    var i = startIndex
    var j = endIndex
    while (i<j) {
        let temp = result[i]
        result[i] = result[j]
        result[j] = temp
        i+=1
        j-=1
    }
    return result
}

getPigLatin(array: ["P","T","R","A","I", "S"])
getPigLatin(array: ["A","T","R","A","I", "S"])
getPigLatin(array: ["P","T","R","G","B", "S"])
