import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

struct EmployeeResponse: Decodable {
    let status: String
    let data: DataClass
    let message: String
}

// MARK: - DataClass
struct DataClass: Decodable {
    let id: Int
    let employeeName: String
    let employeeSalary, employeeAge: Int
    let profileImage: String

    enum CodingKeys: String, CodingKey {
        case id
        case employeeName = "employee_name"
        case employeeSalary = "employee_salary"
        case employeeAge = "employee_age"
        case profileImage = "profile_image"
    }
}


struct Employee {
    func getEmployeeData() {
        let employeeApiUrl = "https://dummy.restapiexample.com/api/v1/employee/1"
        
        URLSession.shared.dataTask(with: URL(string: employeeApiUrl)!) { (responseData, httpUrlResponse, error) in
            if(error == nil && responseData != nil && responseData?.count != 0) {
                //Parse response data here
                let decoder = JSONDecoder()
                do {
                    let result = try decoder.decode(EmployeeResponse.self, from: responseData!)
                    print(result.data.employeeName)
                } catch let error {
                    print("Error occured while dubugging = \(error.localizedDescription)")
                }
            }
        }.resume()
    }
}

let objEmployee = Employee()
objEmployee.getEmployeeData()

