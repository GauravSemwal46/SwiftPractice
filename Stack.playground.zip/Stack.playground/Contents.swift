import UIKit

class Stack<T> {
    private var array: [T] = []
    
    func push(_ item: T) {
        array.append(item)
    }
    
    func pop() -> T? {
        array.popLast()
    }
    
    func peek() -> T? {
        array.last
    }
    
    var isEmpty: Bool {
        array.isEmpty
    }
    
    var count: Int {
        array.count
    }
}

class Queue<T> {
    private var array: [T] = []
    
    func enqueue(_ item: T) {
        array.append(item)
    }
    
    func dequeue() -> T? {
        if isEmpty {
            return nil
        } else {
            return array.removeFirst()
        }
    }
    
    func peek() -> T? {
        array.first
    }
    
    var isEmpty: Bool {
        array.isEmpty
    }
    
    var count: Int {
        array.count
    }
}

struct StackStruct<T> {
    fileprivate var array = [T]()
    
    mutating func push(_ item: T) {
        array.append(item)
    }
    
    mutating func pop() -> T? {
        array.popLast()
    }
    
    var peak: T? {
        array.last
    }
    
    var isEmpty: Bool {
        array.isEmpty
    }
    
    var count: Int {
        array.count
    }
}

struct StructQueue<T> {
    private var array: [T] = []
    
    mutating func enqueue(_ item: T) {
        array.append(item)
    }
    
    mutating func dequeue() -> T? {
        if isEmpty {
            return nil
        } else {
            return array.removeFirst()
        }
    }
    
    func peek() -> T? {
        array.first
    }
    
    var isEmpty: Bool {
        array.isEmpty
    }
    
    var count: Int {
        array.count
    }
}


// Rotate array to right N times
func solutionQueueRight(A: [Int], k: Int) -> [Int] {
    guard !A.isEmpty else { return [] }
    guard k>0 else { return A }
    var result = A
    
    //treat like a queue enqueing and dequeing off the end
    for _ in 1...k {
        let last = result.last!
        result.insert(last, at: 0)
        result.remove(at: A.count)
    }
    return result
}

solutionQueueRight(A: [1,2,3,4,5], k: 2)


// Rotate array to left N times
func solutionQueueLeft(A: [Int], k: Int) -> [Int] {
    guard !A.isEmpty else { return [] }
    guard k>0 else { return A }
    var result = A
    
    //treat like a queue enqueing and dequeing off the end
    for _ in 1...k {
        let first = result.first!
        result.append(first)
        result.remove(at: 0)
    }
    return result
}
solutionQueueLeft(A: [1,2,3,4,5], k: 2)


/*
 Giving a String, write a function that reverse the string using stack
 */

func solution(_ text: String) -> String {
    var chars = Array(text)
    
    //Create a stack
    var result = [String]()
    
    //Pushing chars
    for c in chars {
        result.append(String(c))
    }
    
    //Pop chars
    for i in 0..<result.count {
        chars[i] = Character(result.popLast()!)
    }
    print(chars)
    return String(chars)
}

solution("abc") // cba
solution("Would you like to play a game?")
