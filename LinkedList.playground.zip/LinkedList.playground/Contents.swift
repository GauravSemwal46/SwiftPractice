import UIKit

//Linked - List
// Problem Statement-  With array adding element at front O(n). Size constraint. We can solve this using Linked-List.


// A linked list is simply a node with a pointer to next.

class Node {
    var data: Int
    var next: Node?
    
    init(_ data: Int, _ next: Node? = nil) {
        self.data = data
        self.next = next
    }
}

class LinkList {
    private var head: Node?
    
    // Add element at front O(1)
    func addFront(_ data: Int) {
        let newNode = Node(data)
        newNode.next = head
        head = newNode
    }
    
    // Get first element O(1)
    func getFirst() -> Int? {
        if head == nil { return nil }
        return head?.data
    }
    
    // Add to back of link list O(n)
    func addBack(_ data: Int) {
        let newNode = Node(data)
        
        if head == nil {
            head = newNode
            return
        }
        
        var node = head!
        while node.next != nil {
            node = node.next!
        }
        node.next = newNode
    }
    
    // Get last element O(n)
    func getLast() -> Int? {
        if head == nil { return nil }
        var node = head!
        while node.next != nil {
            node = node.next!
        }
        return node.data
    }
    
    //Insert element at any position
    func insert(position: Int, data: Int) {
        if position == 0 {
            addFront(data)
            return
        }
        
        let newNode = Node(data)
        var currentNode = head
        
        for _ in 0..<position-1 {
            currentNode = currentNode?.next
        }
        
        newNode.next = currentNode?.next
        currentNode?.next = newNode
    }
    
    // Delete first element
    func deleteFirst() {
        head = head?.next
    }
    
    // Delete last element at one go
    func deleteLast() {
        if (head?.next == nil) {
            head = nil
        }
        var node = head
        
        while (node?.next?.next != nil) {
            node = node?.next
        }
        node?.next = nil
    }
    
    // Delete element at any position
    func delete(at position: Int) {
        if position == 0 { head = head?.next }
        var currentNode = head
        
        for _ in 0..<position-1 {
            currentNode = currentNode?.next
        }
        currentNode?.next = currentNode?.next?.next
    }
    
    // Check if linked list is empty
    var isEmpty: Bool {
        return head == nil
    }
    
    func length() -> Int {
        if head == nil { return 0 }
        var count = 1
        var node = head
        while (node?.next != nil) {
            count += 1
            node = node?.next
        }
        return count
    }
    
    // Clear the link list.
    func clear() {
        head = nil
    }
    
    // To print all the element in the linked-list
    func printLinkedList() {
        if head == nil {return}
        
        var result = [Int]()
        var node = head
        result.append(node!.data)
        
        while node?.next != nil {
            result.append(node!.next!.data)
            node = node?.next
        }
        
        print(result)
    }
}

func length(_ head: Node?) -> Int {
    if head == nil { return 0 }
    var count = 1
    var node = head
    while (node?.next != nil) {
        count += 1
        node = node?.next
    }
    return count
}

func findMergeBrute(headA: Node?, headB: Node?) -> Int? {
    let lengthHeadA = length(headA)
    let lengthHeadB = length(headB)
    
    var currentA = headA
    
    for _ in 0..<lengthHeadA-1 {
        var currentB = headB
        for _ in 0..<lengthHeadB-1 {
            if currentA?.data == currentB?.data {
                return currentA?.data
            }
            currentB = currentB?.next
        }
        currentA = currentA?.next
    }
    return nil
}

func findMergeSpaceTime(headA: Node?, headB: Node?) -> Int? {
    let lengthHeadA = length(headA)
    let lengthHeadB = length(headB)
    
    var dict = [Int? : Bool]()
    var currentB = headB
    
    for _ in 0..<lengthHeadB-1 {
        let B = currentB?.data
        dict[B] = true
        currentB = currentB?.next
    }
    
    var currentA = headA
    for _ in 0..<lengthHeadA-1 {
        let A = currentA?.data
        if dict[A] == true {
            return A
        }
        currentA = currentA?.next
    }
    return nil
}

func findMergeInsight(headA: Node?, headB: Node?) -> Int? {
    let lengthHeadA = length(headA)
    let lengthHeadB = length(headB)
    
    var currentA = headA
    var currentB = headB
    if lengthHeadA < lengthHeadB {
        let temp = currentA
        currentA = currentB
        currentB = temp
    }
    
    let diff = abs(lengthHeadA - lengthHeadB)
    for _ in 1...diff {
        currentA = currentA?.next
    }
    
    for _ in 0..<lengthHeadB-1 {
        if (currentA?.data == currentB?.data) {
            return currentA?.data
        }
        currentB = currentB?.next
    }
    return nil
}

func hasCycle(first: Node) -> Bool {
    var slow: Node? = first
    var fast: Node? = first
    
    while fast != nil && fast!.next != nil {
        slow = slow?.next
        fast = fast?.next?.next
        if slow?.data == fast?.data {
            return true
        }
    }
    return false
}

let node5 = Node(5)
let node4 = Node(4)
let node3 = Node(3)
let node2 = Node(2)
let head = Node(1)

head.next = node2
node2.next = node3
node3.next = node4
node4.next = node5
node5.next = node3

hasCycle(first: head)


//let node3 = Node(3)
//let node2 = Node(2, node3)
//let node1 = Node(1, node2)
//
//let node8 = Node(8)
//let node10 = Node(10, node2)
//let node9 = Node(9, node10)
//
//let mergePoint = findMergeBrute(headA: node10, headB: node2)
//print(mergePoint ?? "No merge point")
//
//let mergePoint2 = findMergeBrute(headA: node10, headB: node2)
//print(mergePoint2 ?? "No merge point")
//
//let mergePoint3 = findMergeInsight(headA: node2, headB: node10)
//print(mergePoint3 ?? "No merge point")


